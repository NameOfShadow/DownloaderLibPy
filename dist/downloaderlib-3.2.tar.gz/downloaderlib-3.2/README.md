*downloaderlib - is a small library that makes downloading easier, with this library you can download picture, audio and GitHub code.*

**from downloaderlib import *  -/import the library**

**downloader.picture(link, name_dir) -/link - link to picture, name_dir - folder where this picture will be downloaded**

**downloader.code(link, name_dir) -/ link - link to code, name_dir - folder where this code will be downloaded**

**downloader.audio(link, name_dir) -/ link - link to audio, name_dir - folder where this audio will be downloaded**

*The main thing is that at the end of the link there should be the format mp3, md, py, js, etc.*